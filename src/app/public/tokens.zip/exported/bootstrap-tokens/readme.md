# Bootstrap 5.2 Design Tokens

These files map handoff design tokens to bootstrap 5.2.  